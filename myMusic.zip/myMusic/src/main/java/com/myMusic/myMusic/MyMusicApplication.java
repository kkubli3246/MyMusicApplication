package com.myMusic.myMusic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyMusicApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyMusicApplication.class, args);
	}

}

package com.myMusic.myMusic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyMusicApplicationTests {

	@Test
	void contextLoads() {
	}

}
